class Book:
    def _init_(self,title,author):
        self.title = title
        self.author = author
    
    def display_info():
        print (f"Title: {self.title}, Author: {self.author}")
